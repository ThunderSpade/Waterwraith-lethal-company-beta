# ImmortalSnail
Adds the legendary Immortal Snail as an enemy.

When spawned, the snail selects the nearest player and slowly moves towards them, killing them instantly on contact.
Then it chooses closest living player as its next target.
If the snail touches a non-targeted player, that player will be unaffected.

All players in a lobby must have the mod installed.

Special thanks to grandmastersluggy for coming up with the idea for this mod, and to the amazing LC Modding Discord community, without whom this project wouldn't be possible.

Feel free to reach out on Discord (bigswandawg) for bug reports or suggestions!
